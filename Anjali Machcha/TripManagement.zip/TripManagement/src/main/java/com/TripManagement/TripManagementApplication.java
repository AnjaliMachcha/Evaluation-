package com.TripManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripManagementApplication.class, args);
	}

}
